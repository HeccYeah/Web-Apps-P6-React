﻿namespace Project5.Models
{
    public class HasCourseGen
    {
        public int Id { get; set; }

        public int planId { get; set; }

        public int courseId { get; set; }
        public string sem { get; set; }
        public int year { get; set; }
    }
}
